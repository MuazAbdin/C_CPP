// Activation.cpp

#ifndef ACTIVATION_CPP
#define ACTIVATION_CPP


/**
* @file Activation.cpp
* @author  Muaz Abdeen <muaz.abdeen@mail.huji.ac.il>
* @ID 300575297
* @date 13 May 2020
*
*
* @section DESCRIPTION
* 			.
*/


#include "Activation.h"
#include <cmath>

/**
 * @brief Activate the function on the given matrix.
 */
const Matrix Activation::operator()(const Matrix &m) const
{
	Matrix activeMatrix(m.getRows(), m.getCols());
	if (getActivationType() == Relu)
	{
		for (int i = 0; i < m.getRows(); i++)
		{
			if (m[i] >= 0)
			{
				activeMatrix[i] = m[i];
			}
			else
			{
				activeMatrix[i] = 0;
			}
		}
	}
	else
	{
		float expSum = 0;
		for (int k = 0; k < m.getRows(); k++)
		{
			expSum += std::exp(m[k]);
		}
		for (int j = 0; j < m.getRows(); j++)
		{
			activeMatrix[j] = (1 / expSum) * std::exp(m[j]);
		}
	}
	return activeMatrix;
}

#endif //ACTIVATION_CPP