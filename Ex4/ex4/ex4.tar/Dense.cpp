// Dense.cpp

#ifndef DENSE_CPP
#define DENSE_CPP

/**
* @file Dense.cpp
* @author  Muaz Abdeen <muaz.abdeen@mail.huji.ac.il>
* @ID 300575297
* @date 13 May 2020
*
*/

#include "Dense.h"

/**
 * @brief Multiply the weight by the given matrix then adding bias.
 */
const Matrix Dense::operator()(const Matrix &m) const
{
//	Activation act(_func);
	Matrix outputMat = getWeights() * m;
	outputMat += getBias();
	return getActivation()(outputMat);
}

#endif //DENSE_CPP