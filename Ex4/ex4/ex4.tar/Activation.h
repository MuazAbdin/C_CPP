//Activation.h
#ifndef ACTIVATION_H
#define ACTIVATION_H

#include "Matrix.h"

/**
 * @enum ActivationType
 * @brief Indicator of activation function.
 */
enum ActivationType
{
	Relu,
	Softmax
};

/**
 * @class Activation class
 */
class Activation
{
private:
	ActivationType _actFunc;

public:
	/**
	 * @brief Constructor.
	 */
	explicit Activation(ActivationType actType) : _actFunc(actType)
	{}

	/**
	 * @brief Getter.
	 */
	ActivationType getActivationType() const
	{ return _actFunc; }

	/**
	 * @brief Activate the function on the given matrix.
	 */
	const Matrix operator()(const Matrix &m) const;
};

#endif //ACTIVATION_H
