#ifndef C_DENSE_H
#define C_DENSE_H

#include "Activation.h"

/**
 * @class Dense.
 */
class Dense
{
private:
	Matrix _weight;
	Matrix _bias;
	Activation _func;
public:
	/**
	 * @brief Constructor
	 * @param layerWeights: layerWeights Matrix
	 * @param layerBias: layerBias Matrix
	 * @param layerActivationType: layer Activation Type
	 */
	Dense(const Matrix &w, const Matrix &bias, const ActivationType actFunc)
			: _weight(w), _bias(bias), _func(actFunc)
	{}

	/**
	 * @brief GetWeights function.
	 */
	const Matrix getWeights() const
	{ return _weight; }

	/**
	 * @brief GetBias function.
 	 */
	const Matrix getBias() const
	{ return _bias; }

	/**
	 * @brief Get function.
	 */
	Activation getActivation() const
	{ return _func; }

	/**
	 * @brief Multiply the weight by the given matrix then adding bias to return it-to Activate.
	 * @param Matrix: given matrix.
	 */
	const Matrix operator()(const Matrix &layerInput) const;

};

#endif //C_DENSE_H
